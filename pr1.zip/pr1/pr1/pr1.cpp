﻿#include <iostream>
int main()
{
	setlocale(0, "rus");
	std::cout << "Введите число n: ";
	int n;
	std::cin >> n;
	int temp = n;
	int count = 0;
	while (temp != 0)
	{
		temp /= 10;
		count++;
	}
	if (count == 0)
	{
		count = 1;
	}
	int min = INT_MAX;
	int max = INT_MIN;
	temp = n;
	for (int i = 0; i < count; i++)
	{
		int lastDigit = temp % 10;
		temp /= 10;
		if (lastDigit < min)
		{
			min = lastDigit;
		}
		if (lastDigit > max)
		{
			max = lastDigit;
		}
	}
	int rez = max - min;
	std::cout << "Разница: " << rez;
}